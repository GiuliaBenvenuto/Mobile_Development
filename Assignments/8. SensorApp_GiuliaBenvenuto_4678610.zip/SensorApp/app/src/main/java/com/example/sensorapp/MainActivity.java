package com.example.sensorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private SensorManager sensorManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // ***** Identifying the available sensors *****
        // Create an instance of SensorManager
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        // Get a listing of every sensor
        List<Sensor> deviceSensors = sensorManager.getSensorList(Sensor.TYPE_ALL);

        // Get the textView to display the number of sensors
        TextView tvSensorNumber = (TextView) findViewById(R.id.text_view_number_sensors);
        String label = tvSensorNumber.getText().toString();
        Integer sensorNumber = deviceSensors.size();
        tvSensorNumber.setText(label + sensorNumber);

        // Get the ScrollView to display the sensor's names
        ScrollView sv = (ScrollView) findViewById(R.id.scrollView);

        // Get the textView to display the sensor's names
        TextView tvSensorNames = (TextView) findViewById(R.id.sensor_names);

        StringBuilder sensorNamesBuilder = new StringBuilder();
        for (Sensor sensor : deviceSensors) {
            String name = sensor.getName();
            sensorNamesBuilder.append(name);
            sensorNamesBuilder.append("\n");
        }
        tvSensorNames.setText(sensorNamesBuilder.toString());
        sv.scrollTo(0, 0);


        // ClickListener for the Real-time light sensor button
        Button bLightSensor = (Button) findViewById(R.id.button_light_sensor);
        bLightSensor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, LightSensorActivity.class));
            }
        });


        // ClickListener for Chart Accelerometer button
        Button bAccelerometer = (Button) findViewById(R.id.button_chart);
        bAccelerometer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, AccelerationActivity.class));
            }
        });
    }
}