package com.example.simplecameraapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class ClickActivity extends AppCompatActivity {

    static final int REQUEST_IMAGE_CAPTURE = 1;
    static Bitmap photo1 = null;

    // Date lastModDate = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_click);

        // Click Listener for the "Click" button
        Button clickButton = (Button) findViewById(R.id.buttonClick);
        clickButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                try {
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                    //File f = new File(android.os.Environment.getExternalStorageDirectory(), "temp.jpg");
                    //takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(f));
                } catch (ActivityNotFoundException e) {
                    // display error state to the user
                }
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                photo1 = (Bitmap) data.getExtras().get("data");

                // TIMESTAMP:
                Date currentTime = Calendar.getInstance().getTime();
                String dateTime = currentTime.toString();
                // Log.d("TIMESTAMP_DEBUG", "value: " + dateTime);


                Intent thumbnailIntent = new Intent(ClickActivity.this, ThumbnailActivity.class);
                thumbnailIntent.putExtra("photo", photo1);
                thumbnailIntent.putExtra("dateAndTime", dateTime);
                startActivity(thumbnailIntent);
            }

        }
    }

}
