package com.example.simplecameraapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Click Listener for the "Take a picture" button:
        Button takeAPicture = (Button)findViewById(R.id.buttonTakePicture);
        takeAPicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent takeAPictureIntent = new Intent(MainActivity.this, ClickActivity.class);
                startActivity(takeAPictureIntent);
            }
        });

        // Click Listener for the "Camera Settings" button:
        Button cameraSettings = (Button)findViewById(R.id.buttonCameraSettings);
        cameraSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cameraSettingsIntent = new Intent(MainActivity.this, Settings1Activity.class);
                startActivity(cameraSettingsIntent);
            }
        });


    }
}