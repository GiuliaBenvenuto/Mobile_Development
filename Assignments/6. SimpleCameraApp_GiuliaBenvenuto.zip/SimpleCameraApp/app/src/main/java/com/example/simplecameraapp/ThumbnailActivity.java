package com.example.simplecameraapp;

import static com.example.simplecameraapp.ClickActivity.REQUEST_IMAGE_CAPTURE;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Date;

public class ThumbnailActivity extends AppCompatActivity {

    static final int REQUEST_IMAGE_CAPTURE = 1;
    static Bitmap photo1 = null;
    static Bitmap photo2 = null;
    boolean firstPhoto = true;
    boolean switchPhoto = false;

    String photo1Date = null;
    String photo2Date = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thumbnail);


        ImageView pictureImageView1 = (ImageView)findViewById(R.id.imageViewPicture1);
        ImageView pictureImageView2 = (ImageView)findViewById(R.id.imageViewPicture2);


        // Click Listener for the "Click" button
        Button photoButton = (Button) findViewById(R.id.buttonPhoto);
        photoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                try {
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                    //File f = new File(android.os.Environment.getExternalStorageDirectory(), "temp.jpg");
                    //takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(f));
                } catch (ActivityNotFoundException e) {
                    // display error state to the user
                }
            }
        });



        Intent intentGetPhoto = getIntent();
        photo1Date = (String)intentGetPhoto.getExtras().get("dateAndTime");
        Log.d("PATH_DEBUG_THUMB", "path: " + photo1Date);

        if(firstPhoto) {
            photo1 = (Bitmap)intentGetPhoto.getExtras().get("photo");
            pictureImageView1.setImageBitmap(photo1);
            firstPhoto = false;
        }
        else {
            // photo2 = (Bitmap) intentGetPhoto.getExtras().get("photo");
            String tmp = photo1Date;
            photo1Date = photo2Date;
            photo2Date  =  tmp;

            pictureImageView1.setImageBitmap(null);
            pictureImageView1.setImageBitmap(photo2);
            pictureImageView2.setImageBitmap(null);
            pictureImageView2.setImageBitmap(photo1);

            switchPhoto = true;
        }

        // Click Listener for the "Click Listener" button
        pictureImageView1.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if(view.equals(pictureImageView1)) {
                    Log.d("DEBUG_LONG", "OK");

                    Bitmap bm1 = ((BitmapDrawable) pictureImageView1.getDrawable()).getBitmap();
                    Bitmap bm2 = ((BitmapDrawable) pictureImageView2.getDrawable()).getBitmap();

                    String tmp = photo1Date;
                    photo1Date = photo2Date;
                    photo2Date  =  tmp;

                    // if (photo2 == null) {
                    if (bm2 == null){
                        firstPhoto = true;
                        pictureImageView1.setImageBitmap(null);
                    } else {
                        // photo2 = null;
                        switchPhoto = false;

                        pictureImageView1.setImageBitmap(null);
                        pictureImageView1.setImageBitmap(photo1);
                        pictureImageView2.setImageBitmap(null);
                    }

                    bm1 = ((BitmapDrawable) pictureImageView1.getDrawable()).getBitmap();
                    bm2 = ((BitmapDrawable) pictureImageView2.getDrawable()).getBitmap();
                    if (bm1 == null && bm2 == null) {
                        firstPhoto = true;
                        switchPhoto = false;
                    }
                }
                return false;
            }
        });

        // Click Listener for the "Click Listener" button
        pictureImageView2.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if(view.equals(pictureImageView2)) {
                    Log.d("DEBUG_LONG", "OK");
                    pictureImageView2.setImageBitmap(null);
                    // photo2 = null;
                    switchPhoto = false;

                    Bitmap bm1 = ((BitmapDrawable) pictureImageView1.getDrawable()).getBitmap();
                    Bitmap bm2 = ((BitmapDrawable) pictureImageView2.getDrawable()).getBitmap();

                    if (bm1 == null && bm2 == null) {
                        firstPhoto = true;
                        switchPhoto = false;
                    }
                }
                return false;
            }
        });

        // Click Listener to get the data and time on imageview1
        pictureImageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(view.equals(pictureImageView1)) {
                    //Log.d("DEBUG_OnClick", "OK1");

                    Context context = getApplicationContext();
                    CharSequence text = photo1Date.toString();
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }
            }
        });

        // Click Listener to get the data and time on imageview2
        pictureImageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(view.equals(pictureImageView2)) {
                    Log.d("DEBUG_OnClick", "OK2");

                    Context context = getApplicationContext();
                    CharSequence text = photo2Date.toString();
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }

            }
        });



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        ImageView pictureImageView1 = (ImageView) findViewById(R.id.imageViewPicture1);
        ImageView pictureImageView2 = (ImageView) findViewById(R.id.imageViewPicture2);

        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {

                if (((BitmapDrawable) pictureImageView1.getDrawable()).getBitmap() ==  null && ((BitmapDrawable) pictureImageView2.getDrawable()).getBitmap() == null) {
                    photo1 = (Bitmap) data.getExtras().get("data");

                    // TIMESTAMP:
                    Date currentTime = Calendar.getInstance().getTime();
                    photo1Date = currentTime.toString();


                    firstPhoto = true;
                    switchPhoto = false;
                } else {
                    photo2 = (Bitmap) data.getExtras().get("data");

                    // TIMESTAMP:
                    Date currentTime = Calendar.getInstance().getTime();
                    photo2Date = currentTime.toString();

                }


                if(!firstPhoto && !switchPhoto) {
                    // Log.d("DEBUG", "onActivityResult");
                    String tmp = photo1Date;
                    photo1Date = photo2Date;
                    photo2Date  =  tmp;

                    pictureImageView1.setImageBitmap(null);
                    pictureImageView1.setImageBitmap(photo2);
                    pictureImageView2.setImageBitmap(null);
                    pictureImageView2.setImageBitmap(photo1);
                    switchPhoto = true;
                } else if (!firstPhoto && switchPhoto) {
                    Bitmap firstPhotoToBeSecond = null;
                    firstPhotoToBeSecond = ((BitmapDrawable)pictureImageView1.getDrawable()).getBitmap();

                    String tmp = photo1Date;
                    photo1Date = photo2Date;
                    photo2Date  =  tmp;

                    pictureImageView1.setImageBitmap(null);
                    pictureImageView1.setImageBitmap(photo2);
                    pictureImageView2.setImageBitmap(null);
                    pictureImageView2.setImageBitmap(firstPhotoToBeSecond);

                } else if (firstPhoto && !switchPhoto) {
                    pictureImageView1.setImageBitmap(photo1);
                    firstPhoto = false;
                    switchPhoto = true;
                }
            }
        }

    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    public String getRealPathFromURI(Uri uri) {
        String path = "";
        if (getContentResolver() != null) {
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null) {
                cursor.moveToFirst();
                int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
                path = cursor.getString(idx);
                cursor.close();
            }
        }
        return path;
    }
}

