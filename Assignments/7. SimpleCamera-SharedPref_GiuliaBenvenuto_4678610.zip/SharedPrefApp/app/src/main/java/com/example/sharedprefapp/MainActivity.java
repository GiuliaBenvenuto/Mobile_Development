package com.example.sharedprefapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {

    EditText edUsername, edLocation;
    Button bSave, bClear, bCloseApp;
    Switch sBackground;


    // SharedPreferences
    private SharedPreferences mPreferences;
    private String sharedPrefFile = "com.example.sharedprefapp";
    //private String sharedPrefFile = "com.example.sharedprefapp";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Shared Preferences
        mPreferences = getSharedPreferences(sharedPrefFile, MODE_PRIVATE);


        // EditText
        edUsername = (EditText) findViewById(R.id.editTextUsername);
        edLocation = (EditText) findViewById(R.id.editTextLocation);


        // Switch
        sBackground = (Switch) findViewById(R.id.switchBackground);
        Log.d("DEBUG_SWITCH", "value: " + sBackground.isChecked());


        // If some SharedPreferences are already been saved restore them in the EdiText objects
        String usernameText = mPreferences.getString("username", "");
        String locationText = mPreferences.getString("location", "");
        edUsername.setText(usernameText);
        edLocation.setText(locationText);
        Log.d("DEBUG_OnCreate", "username: " + usernameText);
        Log.d("DEBUG_OnCreate", "location: " + locationText);

        // If the color of the Background has been changed restore this color
        if(mPreferences.getBoolean("switch", false)) {
            getWindow().getDecorView().setBackgroundColor(Color.GRAY);
            sBackground.setChecked(true);
        } else {
            getWindow().getDecorView().setBackgroundColor(Color.WHITE);
            sBackground.setChecked(false);
        }


        // Button Save + ClickListener
        bSave = (Button) findViewById(R.id.buttonSave);
        bSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usernameText = edUsername.getText().toString();
                String locationText = edLocation.getText().toString();

                Log.d("DEBUG_ed", "username: " + usernameText);
                Log.d("DEBUG_ed", "location: " + locationText);

                SharedPreferences.Editor preferencesEditor = mPreferences.edit();
                preferencesEditor.putString("username", usernameText);
                preferencesEditor.putString("location", locationText);
                preferencesEditor.apply();

                //Log.d("DEBUG_SP", "username: " + mPreferences.getString("username", "username_default"));
                //Log.d("DEBUG_SP", "location: " + mPreferences.getString("location", "location_default"));
            }
        });


        // Button Clear + ClickListener
        bClear = (Button) findViewById(R.id.buttonClear);
        bClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Clear the EditText:
                edUsername.setText("");
                edLocation.setText("");

                // Clear the Shared Preferences:
                SharedPreferences.Editor preferencesEditor = mPreferences.edit();
                preferencesEditor.clear();
                preferencesEditor.apply();

                //Log.d("DEBUG_Clear", "username: " + mPreferences.getString("username", "username_default"));
                //Log.d("DEBUG_Clear", "location: " + mPreferences.getString("location", "location_default"));
            }
        });


        // Button Close App
        bCloseApp = (Button) findViewById(R.id.buttonCloseApp);
        bCloseApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finishAndRemoveTask();
            }
        });

        sBackground.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("DEBUG_SWITCH", "click");
                if (sBackground.isChecked()) {
                    getWindow().getDecorView().setBackgroundColor(Color.GRAY);
                    // Save the Background color in the Shared Preferences:
                    SharedPreferences.Editor preferencesEditor = mPreferences.edit();
                    preferencesEditor.putBoolean("switch", sBackground.isChecked());
                    preferencesEditor.apply();
                } else {
                    getWindow().getDecorView().setBackgroundColor(Color.WHITE);
                    // Save the Background color in the Shared Preferences:
                    SharedPreferences.Editor preferencesEditor = mPreferences.edit();
                    preferencesEditor.putBoolean("switch", sBackground.isChecked());
                    preferencesEditor.apply();
                }
            }
        });
    }


    // OnPause() method:
    @Override
    protected void onPause() {
        super.onPause();
        String usernameText = edUsername.getText().toString();
        String locationText = edLocation.getText().toString();

        SharedPreferences.Editor preferencesEditor = mPreferences.edit();
        preferencesEditor.putString("username", usernameText);
        preferencesEditor.putString("location", locationText);
        preferencesEditor.putBoolean("switch", sBackground.isChecked());
        preferencesEditor.apply();
    }

}