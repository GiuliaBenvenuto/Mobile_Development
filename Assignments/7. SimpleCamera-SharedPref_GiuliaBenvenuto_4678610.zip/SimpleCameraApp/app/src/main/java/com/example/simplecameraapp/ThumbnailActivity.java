package com.example.simplecameraapp;

import static com.example.simplecameraapp.ClickActivity.REQUEST_IMAGE_CAPTURE;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.StatFs;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Date;

public class ThumbnailActivity extends AppCompatActivity {

    static final int REQUEST_IMAGE_CAPTURE = 1;
    static Bitmap photo1 = null;
    static Bitmap photo2 = null;
    static Bitmap firstPhotoToBeSecond = null;
    boolean firstPhoto = true;
    boolean switchPhoto = false;
    boolean availableExt = false;

    String photo1Date = null;
    String photo2Date = null;
    String absolutePathPhoto = " ";

    private static final int LONG_DELAY = 3500; // 3.5 seconds
    private static final int SHORT_DELAY = 2000; // 2 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thumbnail);


        ImageView pictureImageView1 = (ImageView)findViewById(R.id.imageViewPicture1);
        ImageView pictureImageView2 = (ImageView)findViewById(R.id.imageViewPicture2);

        File[] externalStorageVolumes = ContextCompat.getExternalFilesDirs(getApplicationContext(), Environment.DIRECTORY_PICTURES);
        File pathPrimaryExternalStorage = externalStorageVolumes[0];
        File pathSecondaryExternalStorage = externalStorageVolumes[1];

        // Click Listener Save Int Button
        Button saveIntB = (Button) findViewById(R.id.buttonSaveInt);
        saveIntB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Bitmap photoToSave = ((BitmapDrawable)pictureImageView1.getDrawable()).getBitmap();
                absolutePathPhoto = saveToInternalStorage(photoToSave);

                Log.d("ABSOLUTE_DEBUG", "path: " + absolutePathPhoto);
            }
        });


        // Click Listener Primary External Storage button
        Button saveExtB = (Button) findViewById(R.id.buttonSaveExt);
        saveExtB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Check if the External Storage is available:
                availableExt = isExternalStorageWritable();
                if (availableExt) {

                    // StatFs statFs = new StatFs(Environment.getExternalStorageDirectory().getAbsolutePath());
                    StatFs statFs = new StatFs(pathPrimaryExternalStorage.getAbsolutePath());
                    long bytesAvailable;
                    bytesAvailable = statFs.getBlockSizeLong() * statFs.getAvailableBlocksLong();
                    long megAvailable = bytesAvailable / (1024 * 1024);
                    Log.e("","Available MB : "+ megAvailable);


                    Bitmap photoToSave = ((BitmapDrawable)pictureImageView1.getDrawable()).getBitmap();
                    saveToExternalStorage(photoToSave, pathPrimaryExternalStorage);
                    /*
                    if(firstPhoto) {
                        // Save the image to the external storage:
                        saveToExternalStorage(photo1, pathPrimaryExternalStorage);
                    } else {
                        saveToExternalStorage(firstPhotoToBeSecond, pathPrimaryExternalStorage);
                    }*/

                    // Toasts:
                    Toast.makeText(ThumbnailActivity.this, "Ready", Toast.LENGTH_SHORT).show();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            Toast.makeText(ThumbnailActivity.this, "Free space = " + megAvailable + "MB", Toast.LENGTH_SHORT).show();
                        }
                    }, 2000);
                }
            }
        });


        // Click Listener Secondary External Storage (SD) button
        Button saveExtSD = (Button) findViewById(R.id.buttonSaveExtSD);
        saveExtSD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Check if the External Storage is available:
                availableExt = isExternalStorageWritable();
                if (availableExt) {
                    // StatFs statFs = new StatFs(Environment.getExternalStorageDirectory().getAbsolutePath());
                    StatFs statFs = new StatFs(pathSecondaryExternalStorage.getAbsolutePath());
                    long bytesAvailable;
                    bytesAvailable = statFs.getBlockSizeLong() * statFs.getAvailableBlocksLong();
                    long megAvailable = bytesAvailable / (1024 * 1024);
                    Log.e("","Available MB : "+ megAvailable);


                    Bitmap photoToSave = ((BitmapDrawable)pictureImageView1.getDrawable()).getBitmap();
                    saveToExternalStorage(photoToSave, pathSecondaryExternalStorage);

                    /*
                    if(firstPhoto) {
                        // Save the image to the external SD storage:
                        saveToExternalStorage(photo1, pathSecondaryExternalStorage);
                    } else {
                        saveToExternalStorage(photo2, pathSecondaryExternalStorage);
                    }*/

                    // Toasts:
                    Toast.makeText(ThumbnailActivity.this, "Ready", Toast.LENGTH_SHORT).show();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable()
                    {
                        @Override
                        public void run()
                        {
                            Toast.makeText(ThumbnailActivity.this, "Free space = " + megAvailable + "MB", Toast.LENGTH_SHORT).show();
                        }
                    }, 2000);

                }

            }
        });


        // Click Listener for the "Click" button
        Button photoButton = (Button) findViewById(R.id.buttonPhoto);
        photoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                try {
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                    //File f = new File(android.os.Environment.getExternalStorageDirectory(), "temp.jpg");
                    //takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(f));
                } catch (ActivityNotFoundException e) {
                    // display error state to the user
                }
            }
        });



        Intent intentGetPhoto = getIntent();
        photo1Date = (String)intentGetPhoto.getExtras().get("dateAndTime");
        Log.d("PATH_DEBUG_THUMB", "path: " + photo1Date);

        if(firstPhoto) {
            photo1 = (Bitmap)intentGetPhoto.getExtras().get("photo");
            pictureImageView1.setImageBitmap(photo1);
            firstPhoto = false;
        }
        else {
            // photo2 = (Bitmap) intentGetPhoto.getExtras().get("photo");
            String tmp = photo1Date;
            photo1Date = photo2Date;
            photo2Date  =  tmp;

            pictureImageView1.setImageBitmap(null);
            pictureImageView1.setImageBitmap(photo2);
            pictureImageView2.setImageBitmap(null);
            pictureImageView2.setImageBitmap(photo1);

            switchPhoto = true;
        }


        // Click Listener for the "Click Listener" button
        pictureImageView1.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if(view.equals(pictureImageView1)) {
                    Log.d("DEBUG_LONG", "OK");

                    Bitmap bm1 = ((BitmapDrawable) pictureImageView1.getDrawable()).getBitmap();
                    Bitmap bm2 = ((BitmapDrawable) pictureImageView2.getDrawable()).getBitmap();

                    String tmp = photo1Date;
                    photo1Date = photo2Date;
                    photo2Date  =  tmp;

                    // if (photo2 == null) {
                    if (bm2 == null){
                        firstPhoto = true;
                        pictureImageView1.setImageBitmap(null);
                    } else {
                        // photo2 = null;
                        switchPhoto = false;

                        pictureImageView1.setImageBitmap(null);
                        pictureImageView1.setImageBitmap(photo1);
                        pictureImageView2.setImageBitmap(null);
                    }

                    bm1 = ((BitmapDrawable) pictureImageView1.getDrawable()).getBitmap();
                    bm2 = ((BitmapDrawable) pictureImageView2.getDrawable()).getBitmap();
                    if (bm1 == null && bm2 == null) {
                        firstPhoto = true;
                        switchPhoto = false;
                    }
                }
                return false;
            }
        });


        // Click Listener for the "Click Listener" button
        pictureImageView2.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if(view.equals(pictureImageView2)) {
                    Log.d("DEBUG_LONG", "OK");
                    pictureImageView2.setImageBitmap(null);
                    // photo2 = null;
                    switchPhoto = false;

                    Bitmap bm1 = ((BitmapDrawable) pictureImageView1.getDrawable()).getBitmap();
                    Bitmap bm2 = ((BitmapDrawable) pictureImageView2.getDrawable()).getBitmap();

                    if (bm1 == null && bm2 == null) {
                        firstPhoto = true;
                        switchPhoto = false;
                    }
                }
                return false;
            }
        });


        // Click Listener to get the data and time on imageview1
        pictureImageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(view.equals(pictureImageView1)) {
                    //Log.d("DEBUG_OnClick", "OK1");

                    Context context = getApplicationContext();
                    CharSequence text = photo1Date.toString();
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }
            }
        });


        // Click Listener to get the data and time on imageview2
        pictureImageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(view.equals(pictureImageView2)) {
                    Log.d("DEBUG_OnClick", "OK2");

                    Context context = getApplicationContext();
                    CharSequence text = photo2Date.toString();
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }

            }
        });



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        ImageView pictureImageView1 = (ImageView) findViewById(R.id.imageViewPicture1);
        ImageView pictureImageView2 = (ImageView) findViewById(R.id.imageViewPicture2);

        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {

                if (((BitmapDrawable) pictureImageView1.getDrawable()).getBitmap() ==  null && ((BitmapDrawable) pictureImageView2.getDrawable()).getBitmap() == null) {
                    photo1 = (Bitmap) data.getExtras().get("data");

                    // TIMESTAMP:
                    Date currentTime = Calendar.getInstance().getTime();
                    photo1Date = currentTime.toString();


                    firstPhoto = true;
                    switchPhoto = false;
                } else {
                    photo2 = (Bitmap) data.getExtras().get("data");

                    // TIMESTAMP:
                    Date currentTime = Calendar.getInstance().getTime();
                    photo2Date = currentTime.toString();

                }

                if(!firstPhoto && !switchPhoto) {
                    // Log.d("DEBUG", "onActivityResult");
                    String tmp = photo1Date;
                    photo1Date = photo2Date;
                    photo2Date  =  tmp;

                    pictureImageView1.setImageBitmap(null);
                    pictureImageView1.setImageBitmap(photo2);
                    pictureImageView2.setImageBitmap(null);
                    pictureImageView2.setImageBitmap(photo1);
                    switchPhoto = true;
                } else if (!firstPhoto && switchPhoto) {

                    firstPhotoToBeSecond = ((BitmapDrawable)pictureImageView1.getDrawable()).getBitmap();

                    String tmp = photo1Date;
                    photo1Date = photo2Date;
                    photo2Date  =  tmp;

                    pictureImageView1.setImageBitmap(null);
                    pictureImageView1.setImageBitmap(photo2);
                    pictureImageView2.setImageBitmap(null);
                    pictureImageView2.setImageBitmap(firstPhotoToBeSecond);

                } else if (firstPhoto && !switchPhoto) {
                    pictureImageView1.setImageBitmap(photo1);
                    firstPhoto = false;
                    switchPhoto = true;
                }
            }
        }

    }


    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }


    public String getRealPathFromURI(Uri uri) {
        String path = "";
        if (getContentResolver() != null) {
            Cursor cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null) {
                cursor.moveToFirst();
                int idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
                path = cursor.getString(idx);
                cursor.close();
            }
        }
        return path;
    }


    private String saveToInternalStorage(Bitmap bitmapImage){
        ContextWrapper cw = new ContextWrapper(getApplicationContext());
        // path to /data/data/yourapp/app_data/imageDir
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        // Create imageDir
        File mypath = new File(directory,"photo.jpg");

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);
            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return directory.getAbsolutePath();
    }

    private String saveToExternalStorage(Bitmap bitmapImage, File directory){
        File mypath = new File(directory.getAbsolutePath(),"photo1.jpg");
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);
            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return directory.getAbsolutePath();
    }



    public boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            return true;
        }
        return false;
    }

}

