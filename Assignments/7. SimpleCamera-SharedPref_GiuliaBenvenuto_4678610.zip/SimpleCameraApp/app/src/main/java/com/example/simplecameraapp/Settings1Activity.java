package com.example.simplecameraapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Settings1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings1);

        TextView tvListener = (TextView)findViewById(R.id.textViewListener);

        // Click Listener for the "return" button
        Button returnButton = (Button)findViewById(R.id.buttonReturn);
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent returnIntent = new Intent (Settings1Activity.this, MainActivity.class);
                startActivity(returnIntent);
            }
        });

        // Click Listener for the "Go to setting 2" button
        Button settings2Button = (Button)findViewById(R.id.buttonSettings2);
        settings2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent settings2Intent = new Intent (Settings1Activity.this, Settings2Activity.class);
                startActivity(settings2Intent);
            }
        });

        // Click Listener for the "Click Listener" button
        Button clickListenerButton = (Button)findViewById(R.id.buttonTestListening);
        clickListenerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvListener.setText("Click Event");
            }
        });

        clickListenerButton.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                tvListener.setText("Long Click Event");
                return true;
            }
        });


        // ************************** EditText and Save Text Button **************************
        // Find the storage path:
        File path = getApplicationContext().getFilesDir();

        // EditText to Save a File:
        EditText editTextSaveFile = (EditText) findViewById(R.id.editTextInsertText);

        // Button save text Click Listener
        Button saveTextButton = (Button) findViewById(R.id.buttonSaveText);
        saveTextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String textToSave = editTextSaveFile.getText().toString();

                // Create a new file:
                File file = new File(path, "my-file.txt");
                // Write on the new file:
                try {
                    FileOutputStream stream = new FileOutputStream(file);
                    try {
                        Log.d("DEBUG_FILE", "ok");
                        stream.write(textToSave.getBytes());
                    } finally {
                        stream.close();
                    }
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });


        // ************************** TextView and Read Text Button **************************
        // TextView where to show the text
        TextView tvShowText = (TextView) findViewById(R.id.textViewShowText);

        // Button read text Click Listener
        Button readTextButton = (Button) findViewById(R.id.buttonReadtext);
        readTextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Read from this file
                File file = new File(path, "my-file.txt");

                // Read the file to a String:+
                int length = (int) file.length();
                // Log.d("DEBUG_FILELENGTH", "Value: " + length); --> OK

                byte[] bytes = new byte[length];
                try {
                    FileInputStream in = new FileInputStream(file);
                    try {
                        in.read(bytes);
                    } finally {
                        in.close();
                    }
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }

                String contents = new String(bytes);
                // Log.d("DEBUG_CONTENT", "Value: " + contents);
                tvShowText.setText(contents);
            }
        });



    }
}