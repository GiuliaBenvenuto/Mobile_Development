package com.example.simplecameraapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Settings2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings2);

        // Click Listener for the "Go to setting 1" button
        Button setting1Button = (Button)findViewById(R.id.buttonSetting1);
        setting1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent setting1Intent = new Intent (Settings2Activity.this, Settings1Activity.class);
                startActivity(setting1Intent);
            }
        });

        // Click Listener for the "Go to setting 3" button
        Button setting3Button = (Button)findViewById(R.id.buttonSetting3);
        setting3Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent setting3Intent = new Intent (Settings2Activity.this, Settings3Activity.class);
                startActivity(setting3Intent);
            }
        });
    }
}