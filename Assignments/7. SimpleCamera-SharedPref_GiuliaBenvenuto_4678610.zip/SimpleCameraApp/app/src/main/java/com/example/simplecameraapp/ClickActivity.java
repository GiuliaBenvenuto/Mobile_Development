package com.example.simplecameraapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class ClickActivity extends AppCompatActivity {

    static final int REQUEST_IMAGE_CAPTURE = 1;
    static Bitmap photo1 = null;
    String absolutePathPhoto = " ";

    // Date lastModDate = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_click);

        File path = getApplicationContext().getFilesDir();

        // Click Listener for the "Click" button
        Button clickButton = (Button) findViewById(R.id.buttonClick);
        clickButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                try {
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
                    //File f = new File(android.os.Environment.getExternalStorageDirectory(), "temp.jpg");
                    //takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(f));
                } catch (ActivityNotFoundException e) {
                    // display error state to the user
                }
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                photo1 = (Bitmap) data.getExtras().get("data");

                /* --- TO DIRECTLY SAVE IN THE INTERNAL STORAGE WHEN SHOT A PHOTO ---
                absolutePathPhoto = saveToInternalStorage(photo1);
                Log.d("ABSOLUTE_DEBUG", "path: " + absolutePathPhoto);
                */

                // TIMESTAMP:
                Date currentTime = Calendar.getInstance().getTime();
                String dateTime = currentTime.toString();
                // Log.d("TIMESTAMP_DEBUG", "value: " + dateTime);

                Intent mainactivityIntent = new Intent(ClickActivity.this, MainActivity.class);
                mainactivityIntent.putExtra("path", absolutePathPhoto);


                Intent thumbnailIntent = new Intent(ClickActivity.this, ThumbnailActivity.class);
                thumbnailIntent.putExtra("photo", photo1);
                thumbnailIntent.putExtra("dateAndTime", dateTime);
                startActivity(thumbnailIntent);


            }

        }
    }


    private String saveToInternalStorage(Bitmap bitmapImage){
        ContextWrapper cw = new ContextWrapper(getApplicationContext());
        // path to /data/data/yourapp/app_data/imageDir
        File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
        // Create imageDir
        File mypath = new File(directory,"photo.jpg");

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);
            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return directory.getAbsolutePath();
    }

}
