package com.example.simplecameraapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Settings3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings3);

        // Click Listener for the "Go to setting 2" button
        Button setting2Button = (Button)findViewById(R.id.buttonSetting2);
        setting2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent setting2Intent = new Intent (Settings3Activity.this, Settings2Activity.class);
                startActivity(setting2Intent);
            }
        });
    }
}