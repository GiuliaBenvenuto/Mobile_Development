package com.example.simplecameraapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class MainActivity extends AppCompatActivity {
    String absolutePathInt = "/data/user/0/com.example.simplecameraapp/app_imageDir";
    String absolutePathExt = "";
    boolean availableExt = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // EXTERNAL PRIMARY AND SECONDARY STORAGES:
        File[] externalStorageVolumes = ContextCompat.getExternalFilesDirs(getApplicationContext(), Environment.DIRECTORY_PICTURES);

        // Set the photo stored in the INTERNAL STORAGE
        loadImageFromIntStorage(absolutePathInt);

        // Set the photo stored in the EXTERNAL PRIMARY STORAGE:
        File pathPrimaryExternalStorage = externalStorageVolumes[0];
        absolutePathExt = pathPrimaryExternalStorage.getAbsolutePath();
        availableExt = isExternalStorageReadable();
        if (availableExt) {
            loadImageFromExtStorage(absolutePathExt);
        }


        // Set the photo stored in the EXTERNAL SECONDARY STORAGE:
        File pathSecondaryExternalStorage = externalStorageVolumes[1];
        absolutePathExt = pathSecondaryExternalStorage.getAbsolutePath();
        availableExt = isExternalStorageReadable();
        if (availableExt) {
            loadImageFromExtSDStorage(absolutePathExt);
        }

        // Click Listener for the "Take a picture" button:
        Button takeAPicture = (Button)findViewById(R.id.buttonTakePicture);
        takeAPicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent takeAPictureIntent = new Intent(MainActivity.this, ClickActivity.class);
                startActivity(takeAPictureIntent);
            }
        });


        // Click Listener for the "Camera Settings" button:
        Button cameraSettings = (Button)findViewById(R.id.buttonCameraSettings);
        cameraSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cameraSettingsIntent = new Intent(MainActivity.this, Settings1Activity.class);
                startActivity(cameraSettingsIntent);
            }
        });
    }


    private void loadImageFromIntStorage(String path) {
        try {
            File f = new File(path, "photo.jpg");
            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
            ImageView img = (ImageView)findViewById(R.id.imageViewInt);
            img.setImageBitmap(b);
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }


    private void loadImageFromExtStorage(String path) {
        try {
            //String photoPath = path + "/photo1.jpg";
            File f = new File(path, "photo1.jpg");
            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
            ImageView img = (ImageView) findViewById(R.id.imageViewExt);
            img.setImageBitmap(b);
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void loadImageFromExtSDStorage(String path) {
        try {
            //String photoPath = path + "/photo1.jpg";
            File f = new File(path, "photo1.jpg");
            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
            ImageView img = (ImageView) findViewById(R.id.imageViewExtSD);
            img.setImageBitmap(b);
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state) ||
                Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            return true;
        }
        return false;
    }


}