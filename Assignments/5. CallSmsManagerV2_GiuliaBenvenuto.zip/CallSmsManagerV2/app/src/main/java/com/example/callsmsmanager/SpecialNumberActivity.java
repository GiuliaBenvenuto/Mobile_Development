package com.example.callsmsmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;

public class SpecialNumberActivity extends AppCompatActivity {

    private String specialNumber = "";
    public final static String EXTRA_REPLY = "Special Number";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_special_number);

        Button infoButton = (Button)findViewById(R.id.buttonInfo);
        infoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = "https://en.wikipedia.org/wiki/List_of_emergency_telephone_numbers";
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }
        });
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.radio_emergency:
                if (checked)
                    specialNumber = "11111";
                break;
            case R.id.radio_firefighters:
                if (checked)
                    specialNumber = "22222";
                break;
            case R.id.radio_police:
                if (checked)
                    specialNumber = "33333";
                break;
        }
    }

    public void selectSpecialNumber (View arg0) {
        Log.d("Activity_DEBUG", "Select method");

        //Intent intent = new Intent(this, InternationalCallActivity.class);
        //intent.putExtra("prefix", countryCode);
        //startActivity(intent);

        // Create an intent
        Intent replyIntent = new Intent();

        // Put the data to return into the extra
        replyIntent.putExtra(EXTRA_REPLY, specialNumber);

        // Set the activity's result to RESULT_OK
        setResult(RESULT_OK, replyIntent);

        Log.d("specialNumber_DEBUG", specialNumber);

        // Finish the current activity
        finish();
    }
}