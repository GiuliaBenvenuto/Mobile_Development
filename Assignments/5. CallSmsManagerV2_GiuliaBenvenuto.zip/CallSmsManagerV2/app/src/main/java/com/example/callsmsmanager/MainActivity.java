package com.example.callsmsmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telecom.Call;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private static final String LOG_TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Click Listener for the "make a call" button
        Button makeACall = (Button)findViewById(R.id.buttonMakecall);
        makeACall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent makeACallIntent = new Intent(MainActivity.this, CallActivity.class);
                startActivity(makeACallIntent);
            }
        });

        // Click Listener for the "send an sms" button
        Button sendAnSms = (Button)findViewById(R.id.buttonSendsms);
        sendAnSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sendAnSmsIntent = new Intent(MainActivity.this, SmsActivity.class);
                startActivity(sendAnSmsIntent);
            }
        });

        // Click Listener for the "make an int call"
        Button intCall = (Button)findViewById(R.id.buttonIntCall);
        intCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intCallIntent = new Intent(MainActivity.this, InternationalCallActivity.class);
                startActivity(intCallIntent);
            }
        });

        Log.d(LOG_TAG, "onCreate");

    }

    @Override
    protected void onStart() {
        super.onStart();
        // The activity is about to become visible.
        Log.d(LOG_TAG, "onStart");
    }
    @Override
    protected void onRestart() {
        super.onRestart();
        // The activity is between stopped and started.
        Log.d(LOG_TAG, "onRestart");
    }
    @Override
    protected void onResume() {
        super.onResume();
        // The activity has become visible
        // it is now "resumed"
        Log.d(LOG_TAG, "onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        // Another activity is taking focus
        // this activity is about to be "paused"
        Log.d(LOG_TAG, "onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        // The activity is no longer visible
        // it is now "stopped"
        Log.d(LOG_TAG, "onStop");
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // The activity is about to be destroyed.
        Log.d(LOG_TAG, "onDestroy");
    }
}