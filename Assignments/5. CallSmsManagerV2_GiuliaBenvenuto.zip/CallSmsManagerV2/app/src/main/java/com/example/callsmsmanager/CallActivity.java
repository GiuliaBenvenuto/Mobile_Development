package com.example.callsmsmanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.Manifest;

public class CallActivity extends AppCompatActivity {

    private static final String LOG_TAG = CallActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call);

        Log.d(LOG_TAG, "onCreate");
    }

    public void compose (View v) {
        Log.d("Activity_DEBUG", "Compose method");

        EditText phoneNumber = (EditText)findViewById(R.id.editTextIntPrefix);
        Intent intentImplicit = new Intent(Intent.ACTION_DIAL);
        String uri = "tel:" + phoneNumber.getText().toString();
        intentImplicit.setData(Uri.parse(uri));
        startActivity(intentImplicit);
    }

    public void call (View v) {
        Log.d("Activity_DEBUG", "Call method");

        EditText phoneNumber = (EditText)findViewById(R.id.editTextIntPrefix);
        Intent intentImplicit = new Intent(Intent.ACTION_CALL);
        String uri = "tel:" + phoneNumber.getText().toString();
        intentImplicit.setData(Uri.parse(uri));

        try {
            startActivity(intentImplicit);
        } catch (SecurityException e){
            ActivityCompat.requestPermissions(
                    CallActivity.this,
                    new String[] {Manifest.permission.CALL_PHONE},
                    1
            );
        }
        return;
    }

    @Override
    protected void onStart() {
        super.onStart();
        // The activity is about to become visible.
        Log.d(LOG_TAG, "onStart");
    }
    @Override
    protected void onRestart() {
        super.onRestart();
        // The activity is between stopped and started.
        Log.d(LOG_TAG, "onRestart");
    }
    @Override
    protected void onResume() {
        super.onResume();
        // The activity has become visible
        // it is now "resumed"
        Log.d(LOG_TAG, "onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        // Another activity is taking focus
        // this activity is about to be "paused"
        Log.d(LOG_TAG, "onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        // The activity is no longer visible
        // it is now "stopped"
        Log.d(LOG_TAG, "onStop");
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // The activity is about to be destroyed.
        Log.d(LOG_TAG, "onDestroy");
    }
}