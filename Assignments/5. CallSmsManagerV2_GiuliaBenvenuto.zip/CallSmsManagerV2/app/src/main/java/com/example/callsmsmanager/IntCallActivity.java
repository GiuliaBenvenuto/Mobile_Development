package com.example.callsmsmanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;

public class IntCallActivity extends AppCompatActivity {

    private static final String LOG_TAG = IntCallActivity.class.getSimpleName();
    private String countryCode = "";
    public final static String EXTRA_REPLY = "prefix";

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_int_call);

        Log.d(LOG_TAG, "onCreate");

        Button infoButton = (Button)findViewById(R.id.buttonInfo);
        infoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String url = "https://en.wikipedia.org/wiki/List_of_international_call_prefixes";
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }
        });
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.radio_italy:
                if (checked)
                    countryCode = "+39";
                    Log.d("radioButton", countryCode);
                    break;
            case R.id.radio_germany:
                if (checked)
                    countryCode = "+49";
                    Log.d("radioButton", countryCode);
                    break;
            case R.id.radio_france:
                if (checked)
                    countryCode = "+33";
                    Log.d("radioButton", countryCode);
                break;
        }
    }

    public void selectPrefix (View arg0) {
        Log.d("Activity_DEBUG", "Select method");

        //Intent intent = new Intent(this, InternationalCallActivity.class);
        //intent.putExtra("prefix", countryCode);
        //startActivity(intent);

        // Create an intent
        Intent replyIntent = new Intent();

        // Put the data to return into the extra
        replyIntent.putExtra(EXTRA_REPLY, countryCode);

        // Set the activity's result to RESULT_OK
        setResult(RESULT_OK, replyIntent);

        // Finish the current activity
        finish();
    }

    @Override
    protected void onStart() {
        super.onStart();
        // The activity is about to become visible.
        Log.d(LOG_TAG, "onStart");
    }
    @Override
    protected void onRestart() {
        super.onRestart();
        // The activity is between stopped and started.
        Log.d(LOG_TAG, "onRestart");
    }
    @Override
    protected void onResume() {
        super.onResume();
        // The activity has become visible
        // it is now "resumed"
        Log.d(LOG_TAG, "onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        // Another activity is taking focus
        // this activity is about to be "paused"
        Log.d(LOG_TAG, "onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        // The activity is no longer visible
        // it is now "stopped"
        Log.d(LOG_TAG, "onStop");
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // The activity is about to be destroyed.
        Log.d(LOG_TAG, "onDestroy");
    }
}