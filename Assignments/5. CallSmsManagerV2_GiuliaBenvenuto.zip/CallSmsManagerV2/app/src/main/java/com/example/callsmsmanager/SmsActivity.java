package com.example.callsmsmanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class SmsActivity extends AppCompatActivity {

    private static final String LOG_TAG = SmsActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        Log.d(LOG_TAG, "onCreate");
    }

    public void send (View v) {
        Log.d("Activity_DEBUG", "Send method");

        EditText phoneEdt = (EditText) findViewById(R.id.editTextPhoneSms);
        EditText messageEdt = (EditText) findViewById(R.id.editTextTextMessage);

        String phoneNumber = phoneEdt.getText().toString();
        String message = messageEdt.getText().toString();

        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("smsto:" + phoneNumber));
        intent.putExtra("sms_body", message);

        try {
            startActivity(intent);
        } catch (SecurityException e){
            ActivityCompat.requestPermissions(
                    SmsActivity.this,
                    new String[] {Manifest.permission.SEND_SMS},
                    1
            );
        }
        return;
    }

    @Override
    protected void onStart() {
        super.onStart();
        // The activity is about to become visible.
        Log.d(LOG_TAG, "onStart");
    }
    @Override
    protected void onRestart() {
        super.onRestart();
        // The activity is between stopped and started.
        Log.d(LOG_TAG, "onRestart");
    }
    @Override
    protected void onResume() {
        super.onResume();
        // The activity has become visible
        // it is now "resumed"
        Log.d(LOG_TAG, "onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        // Another activity is taking focus
        // this activity is about to be "paused"
        Log.d(LOG_TAG, "onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        // The activity is no longer visible
        // it is now "stopped"
        Log.d(LOG_TAG, "onStop");
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // The activity is about to be destroyed.
        Log.d(LOG_TAG, "onDestroy");
    }
}