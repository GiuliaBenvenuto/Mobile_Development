package com.example.callsmsmanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class InternationalCallActivity extends AppCompatActivity {

    private static final String LOG_TAG = InternationalCallActivity.class.getSimpleName();
    public static final int CHOOSE_INT_PREFIX_REQUEST = 1;
    public static final int CHOOSE_SPECIAL_NUMBER_REQUEST = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_international_call);

        // Take the prefix and put it in the textView
        Intent intent = getIntent();
        String prefix = intent.getStringExtra("prefix");


        Log.d(LOG_TAG, "onCreate");

        // Choose Button for the Prefix
        Button chooseIntPrefix = (Button)findViewById(R.id.choose1);
        chooseIntPrefix.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent prefixIntent = new Intent(InternationalCallActivity.this, IntCallActivity.class);
                //startActivity(prefixIntent);
                startActivityForResult(prefixIntent, CHOOSE_INT_PREFIX_REQUEST);
            }
        });

        // Choose Button for the Special Number
        Button chooseSpecialNumber = (Button)findViewById(R.id.choose2);
        chooseSpecialNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent prefixIntent = new Intent(InternationalCallActivity.this, SpecialNumberActivity.class);
                //startActivity(prefixIntent);
                startActivityForResult(prefixIntent, CHOOSE_SPECIAL_NUMBER_REQUEST);
            }
        });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CHOOSE_INT_PREFIX_REQUEST) {
            if (resultCode == RESULT_OK) {
                String reply = data.getStringExtra(IntCallActivity.EXTRA_REPLY);
                EditText intPrefix = findViewById(R.id.editTextIntPrefix);
                intPrefix.setText(reply);
            }
        }
        if (requestCode == CHOOSE_SPECIAL_NUMBER_REQUEST) {
            if (resultCode == RESULT_OK) {
                String reply = data.getStringExtra(SpecialNumberActivity.EXTRA_REPLY);
                EditText specialNumberET = findViewById(R.id.editTextTelNumber);
                specialNumberET.setText(reply);
            }
        }
    }

    public void compose (View v) {
        Log.d("Activity_DEBUG", "Compose method");

        EditText prefixInt = (EditText)findViewById(R.id.editTextIntPrefix);
        EditText numberPhone = (EditText)findViewById(R.id.editTextTelNumber);

        if (prefixInt.getText().toString().isEmpty() && numberPhone.getText().toString().isEmpty()) {
            Context context = getApplicationContext();
            CharSequence text = "Choose a prefix and a phone number";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        } else {

            Intent intentImplicit = new Intent(Intent.ACTION_DIAL);

            String finalNumber = prefixInt.getText().toString() + numberPhone.getText().toString();
            String uri = "tel:" + finalNumber;

            intentImplicit.setData(Uri.parse(uri));
            startActivity(intentImplicit);
        }
    }

    public void call (View v) {
        Log.d("Activity_DEBUG", "Call method");

        EditText prefixInt = (EditText)findViewById(R.id.editTextIntPrefix);
        EditText numberPhone = (EditText)findViewById(R.id.editTextTelNumber);

        if (prefixInt.getText().toString().isEmpty() && numberPhone.getText().toString().isEmpty()) {
            Context context = getApplicationContext();
            CharSequence text = "Choose a prefix and a phone number";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        } else {
            Intent intentImplicit = new Intent(Intent.ACTION_CALL);

            String finalNumber = prefixInt.getText().toString() + numberPhone.getText().toString();
            String uri = "tel:" + finalNumber;

            intentImplicit.setData(Uri.parse(uri));

            try {
                startActivity(intentImplicit);
            } catch (SecurityException e) {
                ActivityCompat.requestPermissions(
                        InternationalCallActivity.this,
                        new String[]{Manifest.permission.CALL_PHONE},
                        1
                );
            }
        }
    }


    @Override
    protected void onStart() {
        super.onStart();
        // The activity is about to become visible.
        Log.d(LOG_TAG, "onStart");
    }
    @Override
    protected void onRestart() {
        super.onRestart();
        // The activity is between stopped and started.
        Log.d(LOG_TAG, "onRestart");
    }
    @Override
    protected void onResume() {
        super.onResume();
        // The activity has become visible
        // it is now "resumed"
        Log.d(LOG_TAG, "onResume");
    }
    @Override
    protected void onPause() {
        super.onPause();
        // Another activity is taking focus
        // this activity is about to be "paused"
        Log.d(LOG_TAG, "onPause");
    }
    @Override
    protected void onStop() {
        super.onStop();
        // The activity is no longer visible
        // it is now "stopped"
        Log.d(LOG_TAG, "onStop");
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        // The activity is about to be destroyed.
        Log.d(LOG_TAG, "onDestroy");
    }


}