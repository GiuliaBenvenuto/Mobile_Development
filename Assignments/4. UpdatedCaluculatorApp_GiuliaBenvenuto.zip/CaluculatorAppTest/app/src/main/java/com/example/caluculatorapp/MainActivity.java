package com.example.caluculatorapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private static final DecimalFormat df = new DecimalFormat("0.00");
    Button b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, bSum, bSub, bMul, bDiv, bCanc, bEqual, bDecimal;
    TextView tv;
    Float op1 = new Float(0.0);
    Float op2 = new Float(0.0);
    Float result;
    Boolean newOperation = true;
    Boolean notDecimal = true;
    Integer len;
    String operator = "";
    Boolean oneOperator = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b0 = (Button) findViewById(R.id.button0);
        b1 = (Button) findViewById(R.id.button1);
        b2 = (Button) findViewById(R.id.button2);
        b3 = (Button) findViewById(R.id.button3);
        b4 = (Button) findViewById(R.id.button4);
        b5 = (Button) findViewById(R.id.button5);
        b6 = (Button) findViewById(R.id.button6);
        b7 = (Button) findViewById(R.id.button7);
        b8 = (Button) findViewById(R.id.button8);
        b9 = (Button) findViewById(R.id.button9);
        bSum = (Button) findViewById(R.id.button_sum);
        bSub = (Button) findViewById(R.id.button_sub);
        bMul = (Button) findViewById(R.id.button_mul);
        bDiv = (Button) findViewById(R.id.button_div);
        bCanc = (Button) findViewById(R.id.button_canc);
        bEqual = (Button) findViewById(R.id.button_equal);
        bDecimal = (Button) findViewById(R.id.button_dot);
        tv = (TextView) findViewById(R.id.result);


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String number = tv.getText().toString();
                number += "1";
                tv.setText(number);
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String number = tv.getText().toString();
                number += "2";
                tv.setText(number);
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String number = tv.getText().toString();
                number += "3";
                tv.setText(number);
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String number = tv.getText().toString();
                number += "4";
                tv.setText(number);
            }
        });

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String number = tv.getText().toString();
                number += "5";
                tv.setText(number);
            }
        });

        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String number = tv.getText().toString();
                number += "6";
                tv.setText(number);
            }
        });

        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String number = tv.getText().toString();
                number += "7";
                tv.setText(number);
            }
        });

        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String number = tv.getText().toString();
                number += "8";
                tv.setText(number);
            }
        });

        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String number = tv.getText().toString();
                number += "9";
                tv.setText(number);
            }
        });

        b0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String number = tv.getText().toString();
                number += "0";
                tv.setText(number);
            }
        });

        bDecimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(notDecimal) {
                    String number = tv.getText().toString();
                    number += ".";
                    tv.setText(number);
                    notDecimal = false;
                }

            }
        });

        bSum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                notDecimal = true;
                String tmp = tv.getText().toString();

                if (!tv.getText().toString().isEmpty() && oneOperator == false) {
                    if (operator.isEmpty()) {
                        if (tmp.isEmpty()) {
                            op1 = 0.0f;
                        } else {
                            op1 = Float.valueOf(tmp.substring(0, tmp.length()));
                        }
                        operator = "+";
                        tv.setText(tv.getText().toString() + "+");

                    } else {
                        if (tmp.isEmpty()) {
                            op1 = 0.0f;
                        } else {
                            op1 = Float.valueOf(tmp.substring(0, tmp.length() - 1));
                        }
                        tmp = tmp.substring(0, tmp.length() - 1);
                        tmp = tmp + "+";

                    }
                    len = tmp.length();
                    oneOperator = true;
                }
            }
        });

        bSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                notDecimal = true;
                String tmp = tv.getText().toString();

                if (!tv.getText().toString().isEmpty() && oneOperator == false) {
                    if (operator.isEmpty()) {
                        if (tmp.isEmpty()) {
                            op1 = 0.0f;
                        } else {
                            op1 = Float.valueOf(tmp.substring(0, tmp.length()));
                        }
                        operator = "-";
                        tv.setText(tv.getText().toString() + "-");

                    } else {
                        if (tmp.isEmpty()) {
                            op1 = 0.0f;
                        } else {
                            op1 = Float.valueOf(tmp.substring(0, tmp.length() - 1));
                        }
                        tmp = tmp.substring(0, tmp.length());
                        tmp = tmp + "-";

                    }
                    Log.d("TMP_DEBUG", "Value TMP: " + tmp);
                    len = tmp.length() + 1;
                    Log.d("LEN_DEBUG", "Value LEN: " + len);
                    oneOperator = true;
                }
            }
        });

        bMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                notDecimal = true;
                String tmp = tv.getText().toString();

                if (!tv.getText().toString().isEmpty() && oneOperator == false) {
                    if (operator.isEmpty()) {
                        if (tmp.isEmpty()) {
                            op1 = 0.0f;
                        } else {
                            op1 = Float.valueOf(tmp.substring(0, tmp.length()));
                        }
                        operator = "*";
                        tv.setText(tv.getText().toString() + "*");

                    } else {
                        if (tmp.isEmpty()) {
                            op1 = 0.0f;
                        } else {
                            op1 = Float.valueOf(tmp.substring(0, tmp.length() - 1));
                        }
                        tmp = tmp.substring(0, tmp.length() - 2);
                        tmp = tmp + "*";

                    }
                    len = tmp.length() + 1;
                    oneOperator = true;
                }
            }
        });

        bDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                notDecimal = true;
                String tmp = tv.getText().toString();

                if (!tv.getText().toString().isEmpty() && oneOperator == false) {
                    if (operator.isEmpty()) {
                        if (tmp.isEmpty()) {
                            op1 = 0.0f;
                        } else {
                            op1 = Float.valueOf(tmp.substring(0, tmp.length()));
                        }
                        operator = "/";
                        tv.setText(tv.getText().toString() + "/");

                    } else {
                        if (tmp.isEmpty()) {
                            op1 = 0.0f;
                        } else {
                            op1 = Float.valueOf(tmp.substring(0, tmp.length() - 1));
                        }
                        tmp = tmp.substring(0, tmp.length() - 2);
                        tmp = tmp + "/";

                    }
                    len = tmp.length() + 1;
                    oneOperator = true;
                }
            }
        });

        bEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (op1 != 0.0) {
                    String tmp = tv.getText().toString();

                    Log.d("String_DEBUG", "String value: " + tmp);
                    Log.d("len_DEBUG", "Len value: " + tmp.length());


                    op2 = Float.valueOf(tmp.substring(len, tmp.length()));


                    Log.d("OP_DEBUG", "Value: " + op2);

                    if (operator == "+") {
                        result = op1 + op2;
                        tv.setText(result.toString());
                    } else if (operator == "-") {
                        result = op1 - op2;
                        tv.setText(result.toString());
                    } else if (operator == "*") {
                        result = op1 * op2;
                        tv.setText(result.toString());
                    } else if (operator == "/") {
                        result = op1 / op2;
                        tv.setText(result.toString());
                    }

                    if (!(result == (float) result)) {
                        notDecimal = true;
                    }

                    operator = "";
                    oneOperator = false;

                    //tv.setText(tv.getText().toString() + "");
                }
            }
        });

        bCanc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String tmp = tv.getText().toString();

                if (!tmp.isEmpty()) {
                    tv.setText("");
                    operator = "";
                    op1 = 0.0f;
                    op2 = 0.0f;
                    notDecimal = true;
                    oneOperator = false;
                }
            }
        });


    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        // save info
        outState.putString("text", String.valueOf(tv.getText()));
        outState.putString("operator", operator);
        outState.putFloat("op1", op1);
        outState.putInt("len", len);
        outState.putBoolean("oneOperator", oneOperator);
        outState.putBoolean("notDecimal", notDecimal);
        super.onSaveInstanceState(outState);
    }


    @Override
    protected void onRestoreInstanceState (Bundle mySavedState) {
        super.onRestoreInstanceState(mySavedState);
        if (mySavedState != null) {
            String text_tv = mySavedState.getString("text");
            Log.d("DEBUG_TV", text_tv);
            operator = mySavedState.getString("operator");
            op1 = mySavedState.getFloat("op1");
            len = mySavedState.getInt("len");
            oneOperator = mySavedState.getBoolean("oneOperator");
            notDecimal = mySavedState.getBoolean("notDecimal");
            tv.setText(text_tv);
        }

    }



}