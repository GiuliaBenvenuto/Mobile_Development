package com.example.callsmsmanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;

public class IntCallActivity extends AppCompatActivity {

    private String countryCode = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_int_call);

        Log.d("Activity_DEBUG", "Int Call Activity");
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.radio_italy:
                if (checked)
                    countryCode = "+39";
                    Log.d("radioButton", countryCode);
                    break;
            case R.id.radio_germany:
                if (checked)
                    countryCode = "+49";
                    Log.d("radioButton", countryCode);
                    break;
            case R.id.radio_france:
                if (checked)
                    countryCode = "+33";
                    Log.d("radioButton", countryCode);
                break;
        }
    }

    public void selectPrefix (View arg0) {
        Log.d("Activity_DEBUG", "Select method");

        Intent intent = new Intent(this, InternationalCallActivity.class);
        intent.putExtra("prefix", countryCode);
        startActivity(intent);
    }
}