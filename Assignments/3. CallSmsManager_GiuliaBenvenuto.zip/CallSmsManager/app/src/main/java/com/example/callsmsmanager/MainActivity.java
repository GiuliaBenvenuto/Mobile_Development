package com.example.callsmsmanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telecom.Call;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Click Listener for the "make a call" button
        Button makeACall = (Button)findViewById(R.id.buttonMakecall);
        makeACall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent makeACallIntent = new Intent(MainActivity.this, CallActivity.class);
                startActivity(makeACallIntent);
            }
        });

        // Click Listener for the "send an sms" button
        Button sendAnSms = (Button)findViewById(R.id.buttonSendsms);
        sendAnSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sendAnSmsIntent = new Intent(MainActivity.this, SmsActivity.class);
                startActivity(sendAnSmsIntent);
            }
        });

        // Click Listener for the "make an int call"
        Button intCall = (Button)findViewById(R.id.buttonIntCall);
        intCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intCallIntent = new Intent(MainActivity.this, IntCallActivity.class);
                startActivity(intCallIntent);
            }
        });

    }


}